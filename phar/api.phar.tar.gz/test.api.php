<?php

function square($number){
	return $number * $number;
}


?>