<?php

class rapidria_library{
	public function __construct(){}
}

?>