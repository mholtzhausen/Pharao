<?php

class rapidria_function{
	protected $functionName=NULL;
	protected $library=NULL;
	protected $params=array();
}


?>